package com.SSM.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


import com.SSM.entity.Dept;

@Mapper
public interface DeptDao {
	/**
     * 查询所有
     */
    @Select("SELECT id,name,password,age FROM t_user")     
    List<Dept> findAll();
 
	
	/**
     * 根据用户名称查询用户信息
     *
     */

	@Select("SELECT id,name,password,age FROM t_user where id=#{id}")
    Dept findById(Long id);
	/**
    * 用户数据新增
   */
    @Insert("insert into t_user(id,name,password,age) values (#{id},#{name},#{password},#{age})")
     void addUser(Dept user);  
    
    /**
     * 用户数据修改
     */
    @Update("update t_user set name=#{name},password=#{password},age=#{age} where id=#{id}")
     void updateUser(Dept user);

    /**
     * 用户数据删除
    */
    @Delete("delete from t_user where id=#{id}")
    void deleteUser(Long id);

	
}
