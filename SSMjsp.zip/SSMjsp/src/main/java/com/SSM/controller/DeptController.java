package com.SSM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



import com.SSM.entity.Dept;
import com.SSM.service.DeptService;


@Controller
//@RequestMapping(value = "/api/user")
public class DeptController {

	@Autowired
	private DeptService deptService;
	
	@RequestMapping("/hello")
    public String hello() {
        return "hello";
    }
	
	@RequestMapping("/")
    public String index() {
        return "redirect:/list";
    }
	
	@RequestMapping("/list")
    public String list(Model model) {
    	System.out.println("查询所有");
        List<Dept> users=deptService.findAll();
       //  model.addAttribute往前台传数据，可以传对象，可以传List，通过el表达式 ${}可以获取到，
      // 类似于request.setAttribute("sts",sts)效果一样。
        model.addAttribute("users", users);
        return "user/list";
    }
	
	 @RequestMapping("/toAdd")
	    public String toAdd() {
	        return "user/userAdd";
	    }

	    @RequestMapping("/add")
	    public String add(Dept user) {
	        deptService.addUser(user);
	        return "redirect:/list";
	    }

	    @RequestMapping("/toEdit")
	    public String toEdit(Model model,Long id) {
	        Dept user=deptService.findUserById(id);
	        model.addAttribute("user", user);
	        return "user/userEdit";
	    }

	    @RequestMapping("/edit")
	    public String edit(Dept user) {
	        deptService.updateUser(user);
	        return "redirect:/list";
	    }


	    @RequestMapping("/toDelete")
	    public String delete(Long id) {
	        deptService.deleteUser(id);
	        return "redirect:/list";
	    }
	
	
//	@RequestMapping(value = "/user0", method = RequestMethod.POST)
//    public boolean addUser( Dept user) {
//        System.out.println("开始新增...");
//        return deptService.addUser(user);
//    }
//    
//    @RequestMapping(value = "/user", method = RequestMethod.PUT)
//    public boolean updateUser( Dept user) {
//        System.out.println("开始更新...");
//        return deptService.updateUser(user);
//    }
//    
//    @RequestMapping(value = "/user1", method = RequestMethod.DELETE)
//    public boolean delete(@RequestParam(value = "id", required = true) int id) {
//        System.out.println("开始删除...");
//        return deptService.deleteUser(id);
//    }
//    
//    
//    @RequestMapping(value = "/user2", method = RequestMethod.GET)
//    public Dept findByUserName(@RequestParam(value = "name", required = true) String name) {
//        System.out.println("开始查询...");
//        return deptService.findUserByName(name);
//    }
//    
//    
//    @RequestMapping(value = "/userAll", method = RequestMethod.GET)
//    public List<Dept> findAll() {
//        System.out.println("开始查询所有数据...");
//        return deptService.findAll();
//    }

}